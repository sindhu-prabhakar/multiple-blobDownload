﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Web.Mvc;

namespace MultipleDownloadBlob.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ListBlobs()
        {
            CloudBlobContainer container = GetCloudBlobContainer();
            List<string> blobs = new List<string>();
            foreach (IListBlobItem item in container.ListBlobs(useFlatBlobListing: true))
            {
                if (item.GetType() == typeof(CloudBlockBlob))
                {
                    CloudBlockBlob blob = (CloudBlockBlob)item;
                    if (blob.Properties.StandardBlobTier.ToString() != "Archive")
                    {
                        blobs.Add(blob.Name);
                    }
                }
                else if (item.GetType() == typeof(CloudPageBlob))
                {
                    CloudPageBlob blob = (CloudPageBlob)item;
                    if (blob.Properties.StandardBlobTier.ToString() != "Archive")
                    {
                        blobs.Add(blob.Name);
                    }
                }
                else if (item.GetType() == typeof(CloudBlobDirectory))
                {
                    CloudBlobDirectory dir = (CloudBlobDirectory)item;
                    blobs.Add(dir.Uri.ToString());
                }
            }

            return View(blobs);
        }

        [HttpPost]
        public string Download(FormCollection items)
        {
            string strSelectedShops;
            if (!string.IsNullOrEmpty(items["selectedBlob"]))
            {
                strSelectedShops = items["selectedBlob"];
                string[] allBlobs = strSelectedShops.Split(',');
                for (int i = 0; i < allBlobs.Length; i++)
                {
                    CloudBlobContainer container = GetCloudBlobContainer();
                    CloudBlockBlob blob = container.GetBlockBlobReference(allBlobs[i]);
                    MemoryStream streamM = new MemoryStream();
                    //using (var fileStream = System.IO.File.OpenWrite(@"C:\Users\v-sindpr\BlobDownloads\" + blob.Name.ToString()))
                    //{
                    string _destPath = @"C:\Users\MyName\Documents\BlobDownloads\" + blob.Name.ToString();
                    //blob.DownloadToStreamAsync(streamM);
                    blob.DownloadToFileAsync(_destPath, FileMode.Create);
                   // }
                   
                }
            }


            return "Success!";
        }

        private CloudBlobContainer GetCloudBlobContainer()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConfigurationManager.AppSettings.Get("StorageConnectionString"));
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("yourContainer");
            return container;
        }
    }
}